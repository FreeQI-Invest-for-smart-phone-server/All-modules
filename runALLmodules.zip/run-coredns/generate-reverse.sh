#!/bin/sh
MASTER=/c/extraNET/bin/mylo/run-coredns/nic.lan_modifie
REVERSE=/c/extraNET/bin/mylo/run-coredns/reverse

# Increment SOA serial on master zone file
awk '/SOA/{$6=$6+1} {print $0}' $MASTER > /tmp/zone.new
mv /tmp/zone.new $MASTER
# Generate reverse file
awk '/SOA/{$1="168.192.in-addr.arpa."; print $0}' $MASTER > $REVERSE
tail -n +1 $MASTER | awk '$3=="A"{split($4,addr,"."); print addr[4] "." addr[3] "." addr[2] "." addr[1] ".in-addr.arpa.", "6230 IN PTR", $1}' >> $REVERSE