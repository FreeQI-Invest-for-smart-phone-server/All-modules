
  |=========================================================|
  |			    README			    |
  |=========================================================|
       _________________   __    __   __       ________
      |   __   |   __   | |  |__|  | |  |     |   __   |
      |  |  |  |  |  |  | |__    __| |  |     |  |  |  |
      |  |  |  |  |  |  |    |  |    |  |___  |  |__|  |
      |__|  |__|__|  |__|    |__|    |______| |________|

  |=========================================================|
  |			         			    |
  |=========================================================|

  < MYLO > C'est plusieurs petits programmes batch qui ont été 
	   créer en ligne de commande.cmd ou .reg

   - Veuillez modifier le PATH relatif avant éxécution.
  
   - Pour rechercher l'adresse IP public du smartphone et la 
     transférer dans une variable system : WAN_IPs :
  	
     ---> lancer pour un démarrage lors du boot :  
	  \mylo\runWANip\runWANip.cmd  (modifier le PATH)

     ---> lancer pour supprimer le démarrage lors du boot :  
	  \mylo\runWANip\UnrunWANip.cmd  (modifier les chemins)


   - Pour que le programme s'exécute à chaque démarage de votre PC, 

	  ---> lancer le fichier : runWANip.reg (modifier le PATH)
          ---> pour le supprimer : delWANip.reg 


  |=========================================================|
  |   Laurent PERRET by sysadmsy6@gmail.com - 08-05.2022    |
  |                    ALL Right Reserved                   |
  |=========================================================|

- Je transmets toutes les données des sites créés sous LARAGON via 
- l'adresse IP de l'iPhone de ma carte (internet illimité)
- Ce script permet le transfert sur l'adresse IP de l'iPhone via Ngrok ou curl.

- Le script met à jour la variable %WAN_IPs% directement dans le Registre Windows. (Vous pouvez ajouter cette variable).
- Ceci est un petit programme batch que j'ai modifié/créé à partir des lignes de commande .CMD .REG .VBS
- Veuillez modifier le PATH relatif avant d'exécuter le script : runREGip.reg qui lance automatiquement le runREGip.cmd
   programme au démarrage du pc.
  
- Très utile pour retrouver l'adresse IP publique dynamique de votre smartphone ou iphone connecté par câble à votre PC,
- le script transfère l'adresse IP vers une variable système au démarrage de votre notebook : %WAN_IPs%
- que vous pouvez ajouter et utiliser sous ( Apache dans httpd .conf) sous le nom de variable $WAN_IPs.
- Vous pouvez également l'utiliser sous DOS en utilisant %WAN_IPs%

